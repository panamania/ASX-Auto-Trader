# ASX Auto-Trading Bot (Cloud-Ready)

This bot uses predictions to automatically trade ASX stocks via broker APIs like IG Markets or Interactive Brokers.

## Features
- Loads prediction logic from your own model
- Sends buy/sell orders using a broker API
- Schedules trading checks every 5 minutes
- Hosted on AWS EC2 or any Linux VM

## Setup Instructions

### 1. Clone this repo and install requirements
```bash
pip install -r requirements.txt
```

### 2. Add environment variables
Rename `.env.example` to `.env` and fill in your keys.

### 3. Run the bot
```bash
python main.py
```

### 4. Run on a schedule with cron
Add to your crontab:
```
*/5 * * * * /usr/bin/python3 /home/ubuntu/main.py >> /home/ubuntu/log.txt 2>&1
```

---

## Notes
- Use paper trading before going live.
- Customize `predict_market()` and `execute_trade()` with your logic.